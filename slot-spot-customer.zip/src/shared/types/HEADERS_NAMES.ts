export const enum HEADERS_NAMES {
  AUTHORIZATION = 'Authorization',
}
