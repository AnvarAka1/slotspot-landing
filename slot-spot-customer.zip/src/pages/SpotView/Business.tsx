import React from 'react'

type Props = Record<string, unknown>

function Business(props: Props) {
  return (
    <>content</>
  )
}

export default Business
