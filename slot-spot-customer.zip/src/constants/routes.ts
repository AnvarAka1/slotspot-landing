export const HOME_PATH = '/'
export const BUSINESS_PATH = '/business'

export const COMPANY_LIST_PATH = '/companies'
export const COMPANY_DETAIL_PATH = '/companies/:id'
